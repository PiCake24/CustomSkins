#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Yasuo/Yasuo.bin"
    "DATA/Characters/Yasuo/Animations/Skin0.bin"
    "DATA/Yasuo_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin56_Skins_Skin57_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin68_Skins_Skin69_Skins_Skin7_Skins_Skin70_Skins_Skin71_Skins_Skin72_Skins_Skin73_Skins_Skin74_Skins_Skin75_Skins_Skin76_Skins_Skin77_Skins_Skin78_Skins_Skin79_Skins_Skin8_Skins_Skin80_Skins_Skin81_Skins_Skin82_Skins_Skin83_Skins_Skin84_Skins_Skin85_Skins_Skin86.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin35_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53.bin"
    "DATA/Yasuo_Skins_Skin17_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26.bin"
}
entries: map[hash,embed] = {
    "Characters/Yasuo/Skins/Skin19" = SkinCharacterDataProperties {
        skinClassification: u32 = 2
        championSkinName: string = "YasuoSkin19"
        skinParent: i32 = 17
        metaDataTags: string = "gender:male,faction:ionia,race:human,element:wind,skinline:battleboss"
        loadscreen: embed = CensoredImage {
            image: string = "ASSETS/Characters/Yasuo/Skins/Skin17/YasuoLoadscreen_17.tex"
        }
        loadscreenVintage: embed = CensoredImage {
            image: string = "ASSETS/Characters/Yasuo/Skins/Skin17/YasuoLoadscreen_17_LE.tex"
        }
        skinAudioProperties: embed = skinAudioProperties {
            tagEventList: list[string] = {
                "Yasuo"
            }
            bankUnits: list2[embed] = {
                BankUnit {
                    name: string = "Yasuo_Base_SFX"
                    bankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yasuo/Skins/Base/Yasuo_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yasuo/Skins/Base/Yasuo_Base_SFX_events.bnk"
                    }
                }
                BankUnit {
                    name: string = "Yasuo_Base_SFX"
                    bankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yasuo/Skins/Base/Yasuo_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yasuo/Skins/Base/Yasuo_Base_SFX_events.bnk"
                    }
                    events: list[string] = {
                        "Play_sfx_Yasuo_Dance3D_buffactivate"
                        "Play_sfx_Yasuo_Dance3D_buffactivate_leadin"
                        "Play_sfx_Yasuo_Death3D_cast"
                        "Play_sfx_Yasuo_Joke3D_buffactivate"
                        "Play_sfx_Yasuo_Laugh3D_buffactivate"
                        "Play_sfx_Yasuo_Recall_windup"
                        "Play_sfx_Yasuo_Taunt23D_buffactivate"
                        "Play_sfx_Yasuo_Taunt3D_buffactivate"
                        "Play_sfx_Yasuo_YasuoBasicAttack2_OnCast"
                        "Play_sfx_Yasuo_YasuoBasicAttack2_OnHit"
                        "Play_sfx_Yasuo_YasuoBasicAttack3_OnCast"
                        "Play_sfx_Yasuo_YasuoBasicAttack3_OnHit"
                        "Play_sfx_Yasuo_YasuoBasicAttack4_OnCast"
                        "Play_sfx_Yasuo_YasuoBasicAttack4_OnHit"
                        "Play_sfx_Yasuo_YasuoBasicAttack5_OnCast"
                        "Play_sfx_Yasuo_YasuoBasicAttack5_OnHit"
                        "Play_sfx_Yasuo_YasuoBasicAttack6_OnCast"
                        "Play_sfx_Yasuo_YasuoBasicAttack6_OnHit"
                        "Play_sfx_Yasuo_YasuoBasicAttack_OnCast"
                        "Play_sfx_Yasuo_YasuoBasicAttack_OnHit"
                        "Play_sfx_Yasuo_YasuoCritAttack2_OnCast"
                        "Play_sfx_Yasuo_YasuoCritAttack2_OnHit"
                        "Play_sfx_Yasuo_YasuoCritAttack3_OnCast"
                        "Play_sfx_Yasuo_YasuoCritAttack3_OnHit"
                        "Play_sfx_Yasuo_YasuoCritAttack4_OnCast"
                        "Play_sfx_Yasuo_YasuoCritAttack4_OnHit"
                        "Play_sfx_Yasuo_YasuoCritAttack5_OnCast"
                        "Play_sfx_Yasuo_YasuoCritAttack5_OnHit"
                        "Play_sfx_Yasuo_YasuoCritAttack_OnCast"
                        "Play_sfx_Yasuo_YasuoCritAttack_OnHit"
                        "Play_sfx_Yasuo_YasuoDashWrapper_cast"
                        "Play_sfx_Yasuo_YasuoDashWrapper_hit"
                        "Play_sfx_Yasuo_YasuoEQComboSoundHit_OnBuffActivate"
                        "Play_sfx_Yasuo_YasuoEQComboSoundHit_OnHit"
                        "Play_sfx_Yasuo_YasuoPassiveMSShieldOn_buffdeactivate"
                        "Play_sfx_Yasuo_YasuoPassiveShield_OnBuffActivate"
                        "Play_sfx_Yasuo_YasuoQ2_OnCast"
                        "Play_sfx_Yasuo_YasuoQ3W_hit"
                        "Play_sfx_Yasuo_YasuoQ3W_missilelaunch"
                        "Play_sfx_Yasuo_YasuoQ3W_OnBuffActivate"
                        "Play_sfx_Yasuo_YasuoQ3W_OnBuffDeactivate"
                        "Play_sfx_Yasuo_YasuoQ3W_OnCast"
                        "Play_sfx_Yasuo_YasuoQ_hit"
                        "Play_sfx_Yasuo_YasuoQW_buffactivate"
                        "Play_sfx_Yasuo_YasuoQW_OnCast"
                        "Play_sfx_Yasuo_YasuoRDummySpell_OnCast"
                        "Play_sfx_Yasuo_YasuoRKnockUpCombo_hit_land"
                        "Play_sfx_Yasuo_YasuoRKnockUpCombo_OnBuffActivate"
                        "Play_sfx_Yasuo_YasuoRLeashParticle_buffactivate"
                        "Play_sfx_Yasuo_YasuoSheathSpark_buffactivate"
                        "Play_sfx_Yasuo_YasuoWindWallBuff_missilecast"
                        "Play_sfx_Yasuo_YasuoWMovingWall_buffactivate"
                        "Play_sfx_Yasuo_YasuoWMovingWall_hit"
                        "Play_sfx_Yasuo_YasuoWMovingWall_OnCast"
                        "Stop_sfx_Yasuo_YasuoDashWrapper_cast"
                        "Stop_sfx_Yasuo_YasuoEQComboSoundHit_OnBuffActivate"
                        "Stop_sfx_Yasuo_YasuoQ3W_OnBuffDeactivate"
                        "Stop_sfx_Yasuo_YasuoQW_buffactivate"
                        "Stop_sfx_Yasuo_YasuoRKnockUpCombo_OnBuffActivate"
                    }
                }
                BankUnit {
                    name: string = "Yasuo_Base_VO"
                    bankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_audio.wpk"
                    }
                    events: list[string] = {
                        "Play_vo_Yasuo_Attack2DGeneral"
                        "Play_vo_Yasuo_Death3D"
                        "Play_vo_Yasuo_FirstEncounter3DMasterYi"
                        "Play_vo_Yasuo_FirstEncounter3DRiven"
                        "Play_vo_Yasuo_FirstEncounter3DShen"
                        "Play_vo_Yasuo_FirstEncounter3DYone"
                        "Play_vo_Yasuo_Joke3DGeneral"
                        "Play_vo_Yasuo_Kill3DYone"
                        "Play_vo_Yasuo_Laugh3DGeneral"
                        "Play_vo_Yasuo_Move2DFirstEnemyYone"
                        "Play_vo_Yasuo_Move2DStandard"
                        "Play_vo_Yasuo_Taunt3DGeneral"
                        "Play_vo_Yasuo_YasuoBasicAttack2_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack3_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack4_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack5_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack6_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack2_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack3_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack4_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack5_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack_cast3D"
                        "Play_vo_Yasuo_YasuoEDash_cast3D"
                        "Play_vo_Yasuo_YasuoQ1_cast3D"
                        "Play_vo_Yasuo_YasuoQ2_cast3D"
                        "Play_vo_Yasuo_YasuoQ3Wrapper_cast3D"
                        "Play_vo_Yasuo_YasuoR_cast3D"
                        "Play_vo_Yasuo_YasuoW_cast3D"
                    }
                    voiceOver: bool = true
                }
                BankUnit {
                    name: string = "Yasuo_Base_VO"
                    bankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_audio.wpk"
                    }
                    events: list[string] = {
                        "Play_vo_Yasuo_Attack2DGeneral"
                        "Play_vo_Yasuo_Death3D"
                        "Play_vo_Yasuo_FirstEncounter3DMasterYi"
                        "Play_vo_Yasuo_FirstEncounter3DRiven"
                        "Play_vo_Yasuo_FirstEncounter3DShen"
                        "Play_vo_Yasuo_FirstEncounter3DYone"
                        "Play_vo_Yasuo_Joke3DGeneral"
                        "Play_vo_Yasuo_Kill3DYone"
                        "Play_vo_Yasuo_Laugh3DGeneral"
                        "Play_vo_Yasuo_Move2DFirstEnemyYone"
                        "Play_vo_Yasuo_Move2DStandard"
                        "Play_vo_Yasuo_Taunt3DGeneral"
                        "Play_vo_Yasuo_YasuoBasicAttack2_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack3_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack4_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack5_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack6_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack2_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack3_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack4_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack5_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack_cast3D"
                        "Play_vo_Yasuo_YasuoEDash_cast3D"
                        "Play_vo_Yasuo_YasuoQ1_cast3D"
                        "Play_vo_Yasuo_YasuoQ2_cast3D"
                        "Play_vo_Yasuo_YasuoQ3Wrapper_cast3D"
                        "Play_vo_Yasuo_YasuoR_cast3D"
                        "Play_vo_Yasuo_YasuoW_cast3D"
                    }
                    voiceOver: bool = true
                }
            }
        }
        skinAnimationProperties: embed = skinAnimationProperties {
            animationGraphData: link = "Characters/Yasuo/Animations/Skin0"
        }
        skinMeshProperties: embed = SkinMeshDataProperties {
            skeleton: string = "ASSETS/Characters/Yasuo/Skins/Base/Yasuo.skl"
            simpleSkin: string = "ASSETS/Characters/Yasuo/Skins/Base/Yasuo.skn"
            texture: string = "ASSETS/Characters/Yasuo/Skins/Base/Yasuo_base_TX_CM.dds"
	 	 	skinScale: f32 = 2
            selfIllumination: f32 = 0.699999988
            brushAlphaOverride: f32 = 0.5
            overrideBoundingBox: option[vec3] = {
                { 230, 180, 230 }
            }
            reflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            initialSubmeshToHide: string = "Yasuo_Instrument_Mat, Weapon_Trail"
            materialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    texture: string = "ASSETS/Characters/Yasuo/Skins/Base/Yasuo_Weapon_Trail_TX_CM.dds"
                    submesh: string = "Weapon_Trail"
                }
            }
        }
        idleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                effectKey: hash = 0xe4c8d91f
                boneName: string = "root"
            }
        }
        armorMaterial: string = "Flesh"
        defaultAnimations: list[string] = {
            "Mask"
            "BottleFix_Skin01"
        }
        mContextualActionData: link = "Characters/Yasuo/CAC/Yasuo_Base"
        iconCircle: option[string] = {
            "ASSETS/Characters/Yasuo/HUD/Yasuo_Circle.tex"
        }
        iconSquare: option[string] = {
            "ASSETS/Characters/Yasuo/HUD/Yasuo_Square.tex"
        }
        healthBarData: embed = CharacterHealthBarDataRecord {
            unitHealthBarStyle: u8 = 12
        }
        mResourceResolver: link = "Characters/Yasuo/Skins/Skin0/Resources"
    }
    "Characters/Yasuo/Skins/Skin19/Materials/Diffuse_inst" = StaticMaterialDef {
        name: string = "Characters/Yasuo/Skins/Skin19/Materials/Diffuse_inst"
        samplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                textureName: string = "Diffuse_Texture"
                texturePath: string = "ASSETS/Characters/Yasuo/Skins/Skin19/Yasuo_Skin19_TX_CM.dds"
                addressU: u32 = 1
                addressV: u32 = 1
                addressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                textureName: string = "Mask_Texture_red"
                texturePath: string = "ASSETS/Characters/Yasuo/Skins/Skin17/Yasuo_Skin17_EyeGlow_TX_Mask.dds"
                addressU: u32 = 1
                addressV: u32 = 1
                addressW: u32 = 1
            }
        }
        paramValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                name: string = "Bloom_Intensity"
                value: vec4 = { 35, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                name: string = "Bloom_Color"
                value: vec4 = { 0, 1, 0.719996929, 1 }
            }
            StaticMaterialShaderParamDef {
                name: string = "Alpha_Bias"
                value: vec4 = { 1, 0, 0, 0 }
            }
        }
        switches: list2[embed] = {
            StaticMaterialSwitchDef {
                name: string = "USE_ALPHA"
            }
        }
        shaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                name: string = "normal"
                passes: list[embed] = {
                    StaticMaterialPassDef {
                        shader: link = "Shaders/SkinnedMesh/Diffuse_Bloom"
                        blendEnable: bool = true
                        srcColorBlendFactor: u32 = 6
                        srcAlphaBlendFactor: u32 = 6
                        dstColorBlendFactor: u32 = 7
                        dstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        childTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                name: string = "transition"
                parentName: string = "normal"
                shaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
    }
    "Characters/Yasuo/Skins/Skin19/Materials/Sheath_inst" = StaticMaterialDef {
        name: string = "Characters/Yasuo/Skins/Skin19/Materials/Sheath_inst"
        samplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                textureName: string = "Diffuse_Texture"
                texturePath: string = "ASSETS/Characters/Yasuo/Skins/Skin19/Yasuo_Skin19_TX_CM.dds"
                addressU: u32 = 1
                addressV: u32 = 1
                addressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                textureName: string = "Scroll_01"
                texturePath: string = "ASSETS/Characters/Yasuo/Skins/Skin17/Yasuo_Skin17_SheathMask_TX_Mask.dds"
                addressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                textureName: string = "Mask"
                texturePath: string = "ASSETS/Characters/Yasuo/Skins/Skin17/Yasuo_Skin17_SheathMask_TX_Mask.dds"
                addressU: u32 = 1
                addressV: u32 = 1
                addressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                textureName: string = "Scroll_02"
                texturePath: string = "ASSETS/Characters/Yasuo/Skins/Skin17/Yasuo_Skin17_SheathMask_TX_Mask.dds"
                addressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                textureName: string = "Scroll_03"
                texturePath: string = "ASSETS/Characters/Yasuo/Skins/Skin17/Yasuo_Skin17_SheathMask_TX_Mask.dds"
                addressW: u32 = 1
            }
        }
        paramValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                name: string = "Panning_Noise_Color"
                value: vec4 = { 1, 0, 0.0470588244, 1 }
            }
            StaticMaterialShaderParamDef {
                name: string = "Texture_UV_Scale01"
                value: vec4 = { 1, 2, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                name: string = "ScrollTexture_Control01"
                value: vec4 = { -0.25, -0.5, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                name: string = "Texture_UV_Scale02"
                value: vec4 = { 1, 0.25, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                name: string = "ScrollTexture_Control02"
                value: vec4 = { 0.100000001, -0.25, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                name: string = "Texture_UV_Scale03"
                value: vec4 = { 0.5, 0.5, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                name: string = "ScrollTexture_Control03"
                value: vec4 = { 0.25, -0.300000012, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                name: string = "BloomIntensity"
                value: vec4 = { 1.5, 0, 0, 0 }
            }
        }
        shaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                name: string = "normal"
                passes: list[embed] = {
                    StaticMaterialPassDef {
                        shader: link = "Shaders/SkinnedMesh/MultiMask_Panner_Bloom"
                        blendEnable: bool = true
                        srcColorBlendFactor: u32 = 6
                        srcAlphaBlendFactor: u32 = 6
                        dstColorBlendFactor: u32 = 7
                        dstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        childTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                name: string = "transition"
                parentName: string = "normal"
                shaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        dynamicMaterial: pointer = DynamicMaterialDef {
            parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    name: string = "Panning_Noise_Color"
                    enabled: bool = false
                    driver: pointer = ColorGraphMaterialDriver {
                        driver: pointer = LerpMaterialDriver {
                            mBoolDriver: pointer = IsDeadDynamicMaterialBoolDriver {}
                            mTurnOnTimeSec: f32 = 0
                            mTurnOffTimeSec: f32 = 0
                        }
                        colors: embed = VfxAnimatedColorVariableData {
                            times: list[f32] = {
                                0
                                0.551666677
                            }
                            values: list[vec4] = {
                                { 0.0117647061, 0.78039217, 0.600000024, 1 }
                                { 0, 0, 0, 1 }
                            }
                        }
                    }
                }
            }
        }
    }
    "Characters/Yasuo/Skins/Skin19/Resources" = ResourceResolver {
        resourceMap: map[hash,link] = {
            "Yasuo_BA_Crit_hit_01" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_Crit_hit_01"
            "Yasuo_BA_Crit_hit_02" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_Crit_hit_02"
            "Yasuo_BA_Crit_hit_03" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_Crit_hit_03"
            "Yasuo_BA_Crit_hit_04" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_Crit_hit_04"
            "Yasuo_BA_hit_tar_01" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_hit_tar_01"
            "Yasuo_BA_hit_tar_02" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_hit_tar_02"
            "Yasuo_BA_hit_tar_03" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_hit_tar_03"
            "Yasuo_BA_hit_tar_04" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_hit_tar_04"
            "Yasuo_BA_trail_1" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_trail_1"
            "Yasuo_BA_trail_2" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_trail_2"
            "Yasuo_BA_trail_3" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_trail_3"
            "Yasuo_BA_trail_4" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_trail_4"
            "Yasuo_Dance_flute_wind" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Dance_flute_wind"
            0x635797df = 0x7896c4cf
            "Yasuo_Emote_dance_in_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_dance_in_sound"
            "Yasuo_Emote_dance_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_dance_sound"
            "Yasuo_Emote_death_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_death_sound"
            "Yasuo_Emote_joke_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_joke_sound"
            "Yasuo_Emote_laugh_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_laugh_sound"
            "Yasuo_Emote_taunt2_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt2_sound"
            "Yasuo_Emote_taunt_generic" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt_generic"
            "Yasuo_Emote_taunt_interactive_ninja" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt_interactive_ninja"
            "Yasuo_Emote_taunt_interactive_riven" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt_interactive_riven"
            "Yasuo_Emote_taunt_interactive_yi" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt_interactive_yi"
            "Yasuo_Emote_taunt_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt_sound"
            "Yasuo_EQ3_cas" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_EQ3_cas"
            "Yasuo_EQ_cas" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_EQ_cas"
            "Yasuo_EQ_SwordGlow" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_EQ_SwordGlow"
            "Yasuo_E_Dash" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_E_Dash"
            "Yasuo_E_dash_hit" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_E_dash_hit"
            "Yasuo_E_timer1" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_E_timer1"
            "Yasuo_E_timer2" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_E_timer2"
            "Yasuo_E_timer3" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_E_timer3"
            "Yasuo_E_timer4" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_E_timer4"
            "Yasuo_E_timer5" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_E_timer5"
            "Yasuo_I_sheath_spark" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_I_sheath_spark"
            "Yasuo_NightmareBot_E_timer1" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_NightmareBot_E_timer1"
            "Yasuo_NightmareBot_E_timer2" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_NightmareBot_E_timer2"
            "Yasuo_NightmareBot_E_timer3" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_NightmareBot_E_timer3"
            "Yasuo_NightmareBot_E_timer4" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_NightmareBot_E_timer4"
            "Yasuo_NightmareBot_E_timer5" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_NightmareBot_E_timer5"
            "Yasuo_Passive_Activate" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_passive_activate"
            "Yasuo_Passive_Burst" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Passive_Burst"
            "Yasuo_Q3_Hand" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q3_Hand"
            "Yasuo_Q3_Indicator_Ring" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Q3_Indicator_Ring"
            "Yasuo_Q3_Indicator_Ring_alt" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Q3_Indicator_Ring_alt"
            "Yasuo_Q_Hand" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q_Hand"
            "Yasuo_Q_hit_tar" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Q_hit_tar"
            "Yasuo_Q_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q_sound"
            "Yasuo_Q_WindStrike" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Q_WindStrike"
            "Yasuo_Q_WindStrike_02" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Q_windstrike_02"
            "Yasuo_Q_wind_hit_tar" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Q_wind_hit_tar"
            "Yasuo_Q_wind_mis" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Q_wind_mis"
            "Yasuo_Q_wind_ready_buff" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Q_wind_ready_buff"
            0xc542e434 = 0x229383e4
            0x36a5a16b = 0x18de091b
            "Yasuo_R_cantcast_beam" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_R_cantcast_beam"
            "Yasuo_R_cas_marker_01" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_R_cas_marker_01"
            "Yasuo_R_CloneVFX" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_R_CloneVFX"
            "Yasuo_R_dash" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_R_dash"
            "Yasuo_R_impact_tar" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_R_impact_tar"
            "Yasuo_R_indicator_beam" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_R_indicator_beam"
            "Yasuo_R_land_tar" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_R_land_tar"
            "Yasuo_R_slash_cas" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_R_slash_cas"
            "Yasuo_R_SwordGlow" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_R_SwordGlow"
            "Yasuo_R_tar_imp_01" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_R_tar_imp_01"
            0xf90ee152 = 0xadd28902
            0xf80edfbf = 0xacd2876f
            "Yasuo_Taunt_spit" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Taunt_spit"
            "Yasuo_Wall_XinZhao_OLD" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Wall_XinZhao_OLD"
            "Yasuo_W_windwall1" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_W_windwall1"
            "Yasuo_W_windwall2" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_W_windwall2"
            "Yasuo_W_windwall3" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_W_windwall3"
            "Yasuo_W_windwall4" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_W_windwall4"
            "Yasuo_W_windwall5" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_W_windwall5"
            "Yasuo_W_windwall_activate" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_W_windwall_activate"
            "Yasuo_W_Windwall_big_impact" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_W_windwall_big_impact"
            "Yasuo_W_windwall_enemy_01" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_w_windwall_enemy_01"
            "Yasuo_W_windwall_enemy_02" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_w_windwall_enemy_02"
            "Yasuo_W_windwall_enemy_03" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_w_windwall_enemy_03"
            "Yasuo_W_windwall_enemy_04" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_w_windwall_enemy_04"
            "Yasuo_W_windwall_enemy_05" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_w_windwall_enemy_05"
            "Yasuo_Q_Odyssey_Wandering_wind_mis" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q_wind_mis"
            "Yasuo_Q_Odyssey_Growing_wind_mis" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q_wind_mis"
            "Yasuo_Q_Odyssey_Wandering_Growing_wind_mis" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q_wind_mis"
            "Yasuo_E_Child" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_E_Child"
            "Yasuo_R_SlashChild17" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_R_SlashChild17"
            0x1ed6e26a = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_TarChild_01"
            "Yasuo_BA_CritChild" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_BA_CritChild"
            "Yasuo_Z_RecallSwipes" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Z_RecallSwipes"
            "Yasuo_Z_RecallPoro" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Z_RecallPoro"
            "Yasuo_Z_CorruptingPower" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Z_CorruptingPower"
            "Yasuo_Z_BackGlow" = "Characters/Yasuo/Skins/Skin17/Particles/Yasuo_Skin17_Z_BackGlow"
        }
    }
}
